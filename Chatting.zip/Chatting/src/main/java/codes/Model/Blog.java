package codes.Model;

public class Blog {

}
